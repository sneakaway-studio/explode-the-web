(function() {
	'use strict';

	document.getElementById("link").addEventListener("click", function() {
		window.open('https://sneakaway.studio', '_blank');
	});

}());
