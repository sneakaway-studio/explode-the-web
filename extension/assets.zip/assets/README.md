
# README.md

Assets for the Explode the Web! tutorial
https://github.com/sneakaway-studio/explode-the-web

1. Download and unzip
1. Place entire assets in root of explode-tutorial folder
